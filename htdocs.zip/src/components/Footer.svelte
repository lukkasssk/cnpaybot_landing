<footer class="footer-minimal">
  <div>CNBOT &copy; {new Date().getFullYear()} — Todos os direitos reservados.</div>
</footer>

<style>
.footer-minimal {
  width: 100%;
  text-align: center;
  padding: 1.5rem 0 1rem 0;
  font-size: 1rem;
  color: #888;
  background: transparent;
  letter-spacing: 0.01em;
}
</style> 